import 'package:get/get.dart';
import '../network/api_service.dart';
import 'storage_service.dart';
import 'theme_service.dart';

class InitialServices {
  static Future<void> init() async {
    await _initStorage();
    //await _initApi();
    await _initTheme();
  }

  static Future<void> _initStorage() async {
    await Get.putAsync(() => StorageService().init());
  }

  static Future<void> _initApi() async {
    //await Get.putAsync(() => ApiService().init());
  }

  static Future<void> _initTheme() async {
    await Get.putAsync(() => ThemeService().init());
  }
}