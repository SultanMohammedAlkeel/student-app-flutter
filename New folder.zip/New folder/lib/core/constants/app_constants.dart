import 'dart:ui';

class AppConstants {
  // قيم العمق (Depth)
  static const double lightDepth = 1;
  static const double darkDepth = 1;

  // قيم الشدة (Intensity)
  static const double lightIntensity = 1;
  static const double darkIntensity = 0.3;

  // ألوان الخلفية
  static const Color lightBackgroundColor = Color(0xFFE0E5EC);
  static const Color darkBackgroundColor = Color(0xFF2E3236);

  // الحصول على القيم حسب الثيم الحالي
  static double getDepth(bool isDarkMode) =>
      isDarkMode ? darkDepth : lightDepth;
  static double getIntensity(bool isDarkMode) =>
      isDarkMode ? darkIntensity : lightIntensity;
  static Color getBackgroundColor(bool isDarkMode) =>
      isDarkMode ? darkBackgroundColor : lightBackgroundColor;
}
