import 'package:dio/dio.dart';
import 'package:get/get.dart';
import '../models/user_model.dart';
import '../../core/network/api_service.dart';
import '../../core/services/storage_service.dart';

class AuthRepository {
  final ApiService _apiService = Get.find();
  final StorageService _storage = Get.find();

  // تسجيل الدخول
  Future<UserModel> login(String email, String password) async {
    try {
      final response = await _apiService.post(
        '/login',
        data: {
          'email': email,
          'password': password,
        },
      );

      final user = UserModel.fromJson(response.data['user']);
      
      // حفظ بيانات المستخدم والتوكن محلياً
      await _storage.write('current_user', user);
      await _storage.write('auth_token', user.token);
      
      return user;
    } on DioException catch (e) {
      throw _handleError(e);
    }
  }

  // التسجيل
  Future<UserModel> register(UserModel user) async {
    try {
      final response = await _apiService.post(
        '/auth/register',
        data: {
          'name': user.name,
          'email': user.email,
          'password': user.password,
          'phone_number': user.phoneNumber,
          // يمكن إضافة باقي الحقول حسب الحاجة
        },
      );

      final registeredUser = UserModel.fromJson(response.data['data']);
      return registeredUser;
    } on DioException catch (e) {
      throw _handleError(e);
    }
  }

  // جلب بيانات المستخدم الحالي
  Future<UserModel?> getCurrentUser() async {
    final userJson = _storage.read<Map<String, dynamic>>('current_user');
    if (userJson != null) {
      return UserModel.fromJson(userJson);
    }
    return null;
  }

  // تسجيل الخروج
  Future<void> logout() async {
    await _storage.remove('current_user');
    await _storage.remove('auth_token');
  }

  // تحديث بيانات المستخدم
  Future<UserModel> updateProfile(UserModel user) async {
    try {
      final response = await _apiService.put(
        '/users/${user.id}',
        data: user.toJson(),
      );

      final updatedUser = UserModel.fromJson(response.data['data']);
      
      // تحديث البيانات المحلية
      await _storage.write('current_user', updatedUser.toJson());
      
      return updatedUser;
    } on DioException catch (e) {
      throw _handleError(e);
    }
  }

  // معالجة أخطاء API
  String _handleError(DioException e) {
    if (e.response != null) {
      return e.response?.data['message'] ?? 'حدث خطأ غير متوقع';
    } else {
      return 'حدث خطأ في الاتصال بالخادم';
    }
  }
}