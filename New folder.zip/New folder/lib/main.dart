import 'package:flutter_neumorphic_plus/flutter_neumorphic.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:flutter_staggered_animations/flutter_staggered_animations.dart';
import 'package:get/get.dart';
import 'app/routes/app_pages.dart';
import 'core/services/initial_services.dart';
import 'core/services/theme_service.dart';
import 'core/themes/app_theme.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  
  // تهيئة الخدمات
  await InitialServices.init();

  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return ScreenUtilInit(
      designSize: const Size(360, 690),
      minTextAdapt: true,
      splitScreenMode: true,
      builder: (_, child) {
        return GetMaterialApp(
          title: 'Student App',
          theme: AppTheme.light,
          darkTheme: AppTheme.dark,
          themeMode: Get.find<ThemeService>().theme,
          debugShowCheckedModeBanner: false,
          initialRoute: AppRoutes.initial,
          getPages: AppPages.pages,
          defaultTransition: Transition.fadeIn,
          builder: (context, widget) {
            return NeumorphicTheme(
              theme: NeumorphicThemeData(
                baseColor: Theme.of(context).scaffoldBackgroundColor,
                lightSource: LightSource.topLeft,
                depth: 6,
              ),
              child: AnimationLimiter(
                child: widget!,
              ),
            );
          },
        );
      },
    );
  }
}