import 'package:flutter_neumorphic_plus/flutter_neumorphic.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';

import '../../../core/themes/colors.dart';
import '../controllers/register_controller.dart';
import '../widgets/background_design.dart';
import '../widgets/auth_text_field.dart';

class RegisterView extends GetView<RegisterController> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.backgrounColor,
      body: Directionality(
        textDirection: TextDirection.rtl,
        child: SingleChildScrollView(
          child: SizedBox(
            width: 1.sw,
            height: 1.sh,
            child: Stack(
              children: [
                BackgroundDesign(),
                _buildRegisterForm(),
                Obx(() => controller.showVerification.value 
                    ? _buildVerificationDialog() 
                    : SizedBox()),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildRegisterForm() {
    return Positioned(
      top: 0.15.sh,
      left: 0,
      right: 0,
      bottom: 0,
      child: SingleChildScrollView(
        physics: BouncingScrollPhysics(),
        padding: EdgeInsets.symmetric(horizontal: 24.w),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'تسجيل طالب جديد',
              style: TextStyle(
                fontSize: 28.sp,
                fontWeight: FontWeight.bold,
                color: AppColors.textPrimary,
              ),
            ),
            SizedBox(height: 8.h),
            Text(
              'أكمل البيانات التالية لإنشاء حسابك',
              style: TextStyle(
                fontSize: 14.sp,
                color: AppColors.textSecondary,
              ),
            ),
            SizedBox(height: 30.h),

            // حقل اسم المستخدم
            Obx(() => AuthTextField(
              controller: controller.usernameController,
              hintText: 'اسم المستخدم',
              prefixIcon: Icons.person,
              isRTL: true,
              errorText: controller.usernameError.value,
              onChanged: (value) => controller.usernameError.value = '',
            )),
            SizedBox(height: 16.h),

            // حقل الإيميل
            Obx(() => AuthTextField(
              controller: controller.emailController,
              hintText: 'البريد الإلكتروني',
              prefixIcon: Icons.email,
              isRTL: true,
              keyboardType: TextInputType.emailAddress,
              errorText: controller.emailError.value,
              onChanged: (value) => controller.emailError.value = '',
            )),
            SizedBox(height: 16.h),

            // الرقم الجامعي
            Obx(() => AuthTextField(
              controller: controller.studentIdController,
              hintText: 'الرقم الجامعي',
              prefixIcon: Icons.confirmation_number,
              isRTL: true,
              keyboardType: TextInputType.number,
              errorText: controller.studentIdError.value,
              onChanged: (value) => controller.studentIdError.value = '',
            )),
            SizedBox(height: 16.h),

            // كلمة المرور
            Obx(() => AuthTextField(
              controller: controller.passwordController,
              hintText: 'كلمة المرور',
              prefixIcon: Icons.lock,
              isRTL: true,
              isPassword: true,
              errorText: controller.passwordError.value,
              onChanged: (value) => controller.passwordError.value = '',
            )),
            SizedBox(height: 24.h),

            // زر التسجيل
            _buildRegisterButton(),
            SizedBox(height: 20.h),

            // روابط إضافية
            _buildHelpLinks(),
            SizedBox(height: 40.h),
          ],
        ),
      ),
    );
  }

  Widget _buildVerificationDialog() {
    return Stack(
      children: [
        // طبقة شبه شفافة
        Container(
          color: Colors.black54,
          width: 1.sw,
          height: 1.sh,
        ),
        
        // محتوى الديالوج
        Center(
          child: Neumorphic(
            style: NeumorphicStyle(
              depth: 8,
              intensity: 1,
              color: Colors.grey[200],
              boxShape: NeumorphicBoxShape.roundRect(BorderRadius.circular(20.r)),
            ),
            child: Container(
              width: 0.8.sw,
              padding: EdgeInsets.all(24.w),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Text(
                    'تفعيل الحساب',
                    style: TextStyle(
                      fontSize: 22.sp,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  SizedBox(height: 20.h),
                  Text(
                    'تم إرسال رمز التفعيل إلى بريدك الإلكتروني',
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      fontSize: 14.sp,
                    ),
                  ),
                  SizedBox(height: 20.h),
                  
                  // حقل رمز التفعيل
                  Neumorphic(
                    style: NeumorphicStyle(
                      depth: -4,
                      intensity: 0.8,
                      color: Colors.grey[200],
                    ),
                    child: TextField(
                      controller: controller.activationCodeController,
                      textAlign: TextAlign.center,
                      style: TextStyle(fontSize: 18.sp),
                      decoration: InputDecoration(
                        hintText: 'أدخل رمز التفعيل',
                        border: InputBorder.none,
                      ),
                    ),
                  ),
                  SizedBox(height: 30.h),
                  
                  // أزرار التأكيد والإلغاء
                  Row(
                    children: [
                      Expanded(
                        child: NeumorphicButton(
                          onPressed: () => controller.showVerification.value = false,
                          style: NeumorphicStyle(
                            depth: 4,
                            intensity: 1,
                            color: Colors.grey[300],
                          ),
                          child: Padding(
                            padding: EdgeInsets.symmetric(vertical: 12.h),
                            child: Text('إلغاء'),
                          ),
                        ),
                      ),
                      SizedBox(width: 16.w),
                      Expanded(
                        child: Obx(() => controller.isLoading.value
                            ? Center(child: CircularProgressIndicator())
                            : NeumorphicButton(
                                onPressed: controller.verifyAccount,
                                style: NeumorphicStyle(
                                  depth: 8,
                                  intensity: 1,
                                  color: AppColors.primary,
                                ),
                                child: Padding(
                                  padding: EdgeInsets.symmetric(vertical: 12.h),
                                  child: Text(
                                    'تأكيد',
                                    style: TextStyle(color: Colors.white),
                                  ),
                                ),
                              ),
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildRegisterButton() {
    return Obx(
      () => controller.isLoading.value
          ? Center(child: CircularProgressIndicator())
          : NeumorphicButton(
              onPressed: controller.register,
              style: NeumorphicStyle(
                shape: NeumorphicShape.flat,
                boxShape: NeumorphicBoxShape.roundRect(
                  BorderRadius.circular(12.r),
                ),
                depth: 8,
                intensity: 1,
                color: AppColors.primary,
              ),
              child: Container(
                width: double.infinity,
                padding: EdgeInsets.symmetric(vertical: 14.h),
                alignment: Alignment.center,
                child: Text(
                  'تسجيل الحساب',
                  style: TextStyle(
                    fontSize: 16.sp,
                    fontWeight: FontWeight.bold,
                    color: Colors.white,
                  ),
                ),
              ),
            ),
    );
  }

  Widget _buildHelpLinks() {
    return Column(
      children: [
        // رابط كيف أحصل على رمز التفعيل؟
        GestureDetector(
          onTap: () => _showActivationHelp(),
          child: Text(
            'كيف أحصل على رمز التفعيل؟',
            style: TextStyle(
              fontSize: 14.sp,
              color: AppColors.linkBlue,
              decoration: TextDecoration.underline,
            ),
          ),
        ),
        SizedBox(height: 16.h),

        // رابط لدي حساب بالفعل
        Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text(
              'لديك حساب بالفعل؟ ',
              style: TextStyle(
                fontSize: 14.sp,
                color: AppColors.textSecondary,
              ),
            ),
            GestureDetector(
              onTap: () => Get.back(),
              child: Text(
                'تسجيل الدخول',
                style: TextStyle(
                  fontSize: 14.sp,
                  color: AppColors.secondary,
                  fontWeight: FontWeight.bold,
                  decoration: TextDecoration.underline,
                ),
              ),
            ),
          ],
        ),
      ],
    );
  }

  void _showActivationHelp() {
    Get.dialog(
      Directionality(
        textDirection: TextDirection.rtl,
        child: AlertDialog(
          title: Text('كيفية الحصول على رمز التفعيل'),
          content: Text(
            'سيتم إرسال رمز التفعيل تلقائياً إلى بريدك الإلكتروني بعد إتمام عملية التسجيل. '
            'إذا لم تصلك الرسالة، يرجى التواصل مع الدعم الفني بالجامعة.',
          ),
          actions: [
            TextButton(
              onPressed: () => Get.back(),
              child: Text('حسناً', style: TextStyle(color: AppColors.primary)),
            ),
          ],
        ),
      ),
    );
  }
}