import 'package:get/get.dart';
import 'package:dio/dio.dart';
import 'package:flutter/material.dart';
import 'package:student_app/app/routes/app_pages.dart';
import '../../../core/network/api_service.dart';
import '../../../core/services/auth_service.dart';
import '../../../core/themes/colors.dart';

class RegisterController extends GetxController {
  final ApiService _apiService = ApiService();
  final RxBool isLoading = false.obs;
  final RxBool showVerification = false.obs;
  final RxInt studentId = 0.obs;
  
  final TextEditingController usernameController = TextEditingController();
  final TextEditingController emailController = TextEditingController();
  final TextEditingController studentIdController = TextEditingController();
  final TextEditingController passwordController = TextEditingController();
  final TextEditingController activationCodeController = TextEditingController();

  final RxString usernameError = RxString('');
  final RxString emailError = RxString('');
  final RxString studentIdError = RxString('');
  final RxString passwordError = RxString('');

  @override
  void onClose() {
    usernameController.dispose();
    emailController.dispose();
    studentIdController.dispose();
    passwordController.dispose();
    activationCodeController.dispose();
    super.onClose();
  }

  bool validateFields() {
    bool isValid = true;
    
    // Reset errors
    usernameError.value = '';
    emailError.value = '';
    studentIdError.value = '';
    passwordError.value = '';

    // Username validation
    if (usernameController.text.isEmpty) {
      usernameError.value = 'اسم المستخدم مطلوب';
      isValid = false;
    } else if (usernameController.text.length < 3) {
      usernameError.value = 'يجب أن يكون اسم المستخدم 3 أحرف على الأقل';
      isValid = false;
    }

    // Email validation
    if (emailController.text.isEmpty) {
      emailError.value = 'البريد الإلكتروني مطلوب';
      isValid = false;
    } else if (!GetUtils.isEmail(emailController.text)) {
      emailError.value = 'بريد إلكتروني غير صالح';
      isValid = false;
    }

    // Student ID validation
    if (studentIdController.text.isEmpty) {
      studentIdError.value = 'الرقم الجامعي مطلوب';
      isValid = false;
    } else if (!GetUtils.isNumericOnly(studentIdController.text)) {
      studentIdError.value = 'يجب أن يحتوي الرقم الجامعي على أرقام فقط';
      isValid = false;
    } else if (studentIdController.text.length < 5) {
      studentIdError.value = 'يجب أن يكون الرقم الجامعي 5 أرقام على الأقل';
      isValid = false;
    }

    // Password validation
    if (passwordController.text.isEmpty) {
      passwordError.value = 'كلمة المرور مطلوبة';
      isValid = false;
    } else if (passwordController.text.length < 8) {
      passwordError.value = 'يجب أن تكون كلمة المرور 8 أحرف على الأقل';
      isValid = false;
    }

    return isValid;
  }

  Future<void> register() async {
    if (!validateFields()) return;

    isLoading.value = true;
    
    try {
      final response = await _apiService.post(
        'register',
        data: {
          'username': usernameController.text,
          'email': emailController.text,
          'student_id': studentIdController.text,
          'password': passwordController.text,
        },
      );

      if (response.statusCode == 200 || response.statusCode == 201) {
        studentId.value = response.data['student_id'] ?? 0;
        showVerification.value = true;
        showSuccessSnackbar(
          title: 'نجاح',
          message: response.data['message'] ?? 'تم إرسال رمز التفعيل إلى بريدك الإلكتروني'
        );
      } else {
        handleApiError(response.data);
      }
    } on DioException catch (e) {
      handleDioError(e);
    } catch (e) {
      showErrorSnackbar(title: 'خطأ', message: 'حدث خطأ غير متوقع: ${e.toString()}');
    } finally {
      isLoading.value = false;
    }
  }

   Future<void> verifyAccount() async {
    final code = activationCodeController.text.trim();
    
    if (code.isEmpty) {
      showErrorSnackbar(title: 'خطأ', message: 'الرجاء إدخال رمز التفعيل');
      return;
    }

    isLoading.value = true;
    
    try {
      final response = await _apiService.post(
        'verifyCode',
        data: {
          'code': code,
          'student_id': studentId.value,
          'username': usernameController.text,
          'password': passwordController.text,
          'email': emailController.text,
        },
      );

      if (response.statusCode == 200 || response.statusCode == 201) {
        // حفظ التوكن وبيانات المستخدم
        await AuthService.saveAuthData(
          response.data['token'],
          response.data['user'],
        );

        Get.offAllNamed(AppRoutes.home); // تغيير إلى الصفحة الرئيسية بعد التسجيل
        showSuccessSnackbar(
          title: 'نجاح', 
          message: response.data['message'] ?? 'تم تفعيل الحساب بنجاح'
        );
      } else {
        handleApiError(response.data);
      }
    } on DioException catch (e) {
      handleDioError(e);
    } catch (e) {
      showErrorSnackbar(title: 'خطأ', message: 'حدث خطأ غير متوقع: ${e.toString()}');
    } finally {
      isLoading.value = false;
    }
  }
  void handleApiError(Map<String, dynamic>? data) {
    final error = data?['message'] ?? 
                 data?['error'] ?? 
                 'حدث خطأ في الخادم';
    showErrorSnackbar(title: 'خطأ', message: error.toString());
  }

  void handleDioError(DioException e) {
    final error = e.response?.data?['message'] ?? 
                 e.response?.data?['error'] ?? 
                 e.message ?? 
                 'حدث خطأ في الاتصال';
    showErrorSnackbar(title: 'خطأ', message: error.toString());
  }

  void showSuccessSnackbar({required String title, required String message}) {
    Get.showSnackbar(
      GetSnackBar(
        title: title,
        message: message,
        duration: const Duration(seconds: 3),
        backgroundColor: AppColors.success,
        snackPosition: SnackPosition.TOP,
        margin: const EdgeInsets.all(16),
        borderRadius: 8,
        isDismissible: true,
        dismissDirection: DismissDirection.horizontal,
        forwardAnimationCurve: Curves.easeOutBack,
      ),
    );
  }

  void showErrorSnackbar({required String title, required String message}) {
    Get.showSnackbar(
      GetSnackBar(
        title: title,
        message: message,
        duration: const Duration(seconds: 3),
        backgroundColor: AppColors.error,
        snackPosition: SnackPosition.TOP,
        margin: const EdgeInsets.all(16),
        borderRadius: 8,
        isDismissible: true,
        dismissDirection: DismissDirection.horizontal,
        forwardAnimationCurve: Curves.easeOutBack,
      ),
    );
  }
}