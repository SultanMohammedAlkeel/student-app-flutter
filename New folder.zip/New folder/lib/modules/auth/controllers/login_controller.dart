import 'package:flutter/material.dart';
import 'package:flutter_neumorphic_plus/flutter_neumorphic.dart';
import 'package:get/get.dart';
import 'package:student_app/app/routes/app_pages.dart';
import 'package:student_app/core/services/auth_service.dart';

import '../../../core/utils/helpers/helpers.dart';

class LoginController extends GetxController {
  final TextEditingController emailController = TextEditingController();
  final TextEditingController passwordController = TextEditingController();
  final RxBool isLoading = false.obs;
  final RxBool rememberMe = false.obs;
  final RxBool obscurePassword = true.obs;

  @override
  void onInit() {
    _checkRememberMe();
    super.onInit();
  }

  Future<void> _checkRememberMe() async {
    final remembered = await AuthService.getRememberMeStatus();
    rememberMe.value = remembered;
    if (remembered) {
      final savedEmail = await AuthService.getRememberedEmail();
      if (savedEmail != null) {
        emailController.text = savedEmail;
      }
    }
  }

  Future<void> login() async {
    if (!_validateInputs()) return;

    isLoading.value = true;
    
    try {
      final email = emailController.text.trim();
      final password = passwordController.text.trim();

      // حفظ بيانات تذكرني إذا تم اختيارها
      if (rememberMe.value) {
        await AuthService.setRememberMeStatus(true);
        await AuthService.setRememberedEmail(email);
      } else {
        await AuthService.clearRememberMe();
      }

      // تنفيذ عملية تسجيل الدخول
      final user = await AuthService.login(email, password);
      
      // عرض رسالة النجاح
      showSuccessSnackbar(
        title: 'نجاح',
        message: 'تم تسجيل الدخول بنجاح',
      );

      // الانتقال إلى الصفحة الرئيسية
      Get.offAllNamed(AppRoutes.home);
      
    } catch (e) {
      showErrorSnackbar(
        title: 'خطأ',
        message: e.toString(),
      );
    } finally {
      isLoading.value = false;
    }
  }

  bool _validateInputs() {
    if (emailController.text.isEmpty || !emailController.text.isEmail) {
      showErrorSnackbar(
        title: 'خطأ',
        message: 'الرجاء إدخال بريد إلكتروني صحيح',
      );
      return false;
    }

    if (passwordController.text.isEmpty || passwordController.text.length < 8) {
      showErrorSnackbar(
        title: 'خطأ',
        message: 'كلمة المرور يجب أن تكون 8 أحرف على الأقل',
      );
      return false;
    }

    return true;
  }

  void togglePasswordVisibility() {
    obscurePassword.toggle();
  }

  void goToRegister() {
    Get.toNamed(AppRoutes.register);
  }

  void showSuccessSnackbar({required String title, required String message}) {
    Helpers.showSnackbar(
      title: title,
      message: message,
      isError: false,
    );
  }

  void showErrorSnackbar({required String title, required String message}) {
    Helpers.showSnackbar(
      title: title,
      message: message,
      isError: true,
    );
  }
}