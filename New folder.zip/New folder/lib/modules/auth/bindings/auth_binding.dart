import 'package:get/get.dart';

import '../../../core/network/api_service.dart';
import '../../../data/repositories/auth_repository.dart';
import '../controllers/auth_controller.dart';
import '../controllers/login_controller.dart';
import '../controllers/register_controller.dart';

class AuthBinding implements Bindings {
  @override
  void dependencies() {
    Get.lazyPut(() => AuthController());
    Get.lazyPut(() => LoginController());
    Get.lazyPut<AuthRepository>(() => AuthRepository());
    Get.lazyPut(() => RegisterController());
    Get.lazyPut(()=>ApiService());

    //Get.lazyPut(() => ForgotPasswordController());
  }
}
