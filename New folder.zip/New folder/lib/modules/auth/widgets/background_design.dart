import 'package:flutter/material.dart';
import 'package:flutter_neumorphic_plus/flutter_neumorphic.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';

class BackgroundDesign extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl, // إضافة Directionality للتصميم RTL
      child: Stack(
        children: [
          // الخلفية الأساسية
          Container(
            color: Colors.grey[200],
            height: 0.4.sh,
          ),

          // الدوائر الكبيرة في الأعلى اليسار (بعد عكس التصميم)
          _buildCircleGroup(
            left: 0, // تغيير من right إلى left
            top: -0.05.sh,
            circles: [
              {'size': 220, 'depth': -3, 'convex': true},
              {'size': 180, 'depth': 3, 'convex': false},
              {'size': 140, 'depth': -3, 'convex': true},
              {'size': 100, 'depth': 3, 'convex': false},
            ],
          ),

          // الدوائر المتوسطة في اليمين (بعد عكس التصميم)
          _buildCircleGroup(
            right: -0.05.sw, // تغيير من left إلى right
            bottom: 0.1.sh,
            circles: [
              {'size': 160, 'depth': 3, 'convex': true},
              {'size': 140, 'depth': -3, 'convex': true},
              {'size': 70, 'depth': 3, 'convex': false},
            ],
          ),

          // الدوائر الصغيرة في المنتصف السفلي
          _buildCircleGroup(
            right: 0.52.sw, // تغيير من left إلى right
            bottom: 10,
            circles: [
              {'size': 100, 'depth': 3, 'convex': true},
              {'size': 80, 'depth': -3, 'convex': true},
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildCircleGroup({
    double? left,
    double? right,
    double? top,
    double? bottom,
    required List<Map<String, dynamic>> circles,
  }) {
    return Positioned(
      left: left,
      right: right,
      top: top,
      bottom: bottom,
      child: Stack(
        alignment: Alignment.center,
        children: circles.map((circle) {
          return _buildCircle(
            circle['size'].toDouble(),
            circle['depth'].toDouble(),
            convex: circle['convex'],
          );
        }).toList(),
      ),
    );
  }

  Widget _buildCircle(double size, double depth, {bool convex = false}) {
    return Neumorphic(
      style: NeumorphicStyle(
        shape: convex ? NeumorphicShape.convex : NeumorphicShape.flat,
        boxShape: NeumorphicBoxShape.circle(),
        depth: depth,
        intensity: 1,
        color: Colors.grey[200],
        lightSource: LightSource.topRight, // تغيير مصدر الضوء ليتناسب مع RTL
      ),
      child: SizedBox(
        width: size.w,
        height: size.w,
      ),
    );
  }
}
