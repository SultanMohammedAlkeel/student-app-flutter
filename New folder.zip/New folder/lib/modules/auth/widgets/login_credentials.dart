import 'package:flutter_neumorphic_plus/flutter_neumorphic.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';
import 'package:student_app/modules/auth/controllers/login_controller.dart';

class LoginCredentials extends StatelessWidget {
  final LoginController controller = Get.find<LoginController>();

   LoginCredentials({super.key});

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Positioned(
        top: 0.3.sh,
        left: 0,
        right: 0,
        child: Padding(
          padding: EdgeInsets.all(16.w),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                'مرحباً بك',
                style: TextStyle(
                  fontSize: 35.sp,
                  fontWeight: FontWeight.bold,
                ),
              ),
              Text(
                'لنبدأ الرحلة',
                style: TextStyle(
                  fontSize: 20.sp,
                  color: Colors.black.withOpacity(0.6),
                  fontWeight: FontWeight.w800,
                ),
              ),
              Padding(
                padding: EdgeInsets.symmetric(vertical: 16.h),
                child: Neumorphic(
                  style: NeumorphicStyle(
                    shape: NeumorphicShape.flat,
                    depth: 3,
                    intensity: 1,
                    color: Colors.grey[200],
                    boxShape: NeumorphicBoxShape.roundRect(
                      BorderRadius.circular(30.r),
                    ),
                  ),
                  child: Padding(
                    padding: EdgeInsets.symmetric(horizontal: 16.w),
                    child: TextField(
                      controller: controller.emailController, // ربط بمتحكم البريد الإلكتروني
                      textAlign: TextAlign.right,
                      keyboardType: TextInputType.emailAddress,
                      decoration: InputDecoration(
                        hintText: 'البريد الإلكتروني',
                        border: InputBorder.none,
                        prefixIcon: Icon(Icons.email, textDirection: TextDirection.rtl),
                      ),
                    ),
                  ),
                ),
              ),
              Obx(() => Neumorphic(
                style: NeumorphicStyle(
                  shape: NeumorphicShape.flat,
                  depth: 3,
                  intensity: 1,
                  color: Colors.grey[200],
                  boxShape: NeumorphicBoxShape.roundRect(
                    BorderRadius.circular(30.r),
                  ),
                ),
                child: Padding(
                  padding: EdgeInsets.symmetric(horizontal: 16.w),
                  child: TextField(
                    controller: controller.passwordController, // ربط بمتحكم كلمة المرور
                    textAlign: TextAlign.right,
                    obscureText: controller.obscurePassword.value, // استخدام حالة إخفاء كلمة المرور
                    decoration: InputDecoration(
                      hintText: 'كلمة المرور',
                      border: InputBorder.none,
                      prefixIcon: Icon(Icons.lock, textDirection: TextDirection.rtl),
                      suffixIcon: IconButton(
                        icon: Icon(
                          controller.obscurePassword.value 
                              ? Icons.visibility_off 
                              : Icons.visibility,
                        ),
                        onPressed: controller.togglePasswordVisibility, // ربط بدالة تبديل الرؤية
                      ),
                    ),
                  ),
                ),
              )),
              Padding(
                padding: EdgeInsets.only(top: 8.h),
                child: Align(
                  alignment: Alignment.centerRight,
                  child: GestureDetector(
                    onTap: () {},
                    child: Text(
                      'نسيت كلمة المرور؟',
                      style: TextStyle(
                        fontSize: 14.sp,
                        color: Colors.blue,
                        fontWeight: FontWeight.w600,
                        decoration: TextDecoration.underline,
                      ),
                    ),
                  ),
                ),
              )
            ],
          ),
        ),
      ),
    );
  }
}