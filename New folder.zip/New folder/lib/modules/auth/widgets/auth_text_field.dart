import 'package:flutter/material.dart';
import 'package:flutter_neumorphic_plus/flutter_neumorphic.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';

class AuthTextField extends StatelessWidget {
  final String hintText;
  final IconData prefixIcon;
  final TextEditingController controller;
  final bool isPassword;
  final bool isRTL;
  final TextInputType? keyboardType;
  final String? errorText;
  final Function(String)? onChanged;

  const AuthTextField({
    required this.hintText,
    required this.prefixIcon,
    required this.controller,
    this.isPassword = false,
    this.isRTL = true,
    this.keyboardType,
    this.errorText,
    this.onChanged,
    Key? key,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Neumorphic(
          style: NeumorphicStyle(
            depth: 3,
            intensity: 1,
            color: Colors.grey[200],
            boxShape: NeumorphicBoxShape.roundRect(BorderRadius.circular(30.r)),
          ),
          child: TextField(
            controller: controller,
            obscureText: isPassword,
            keyboardType: keyboardType,
            onChanged: (value) {
              if (onChanged != null) onChanged!(value);
            },
            textAlign: isRTL ? TextAlign.right : TextAlign.left,
            decoration: InputDecoration(
              hintText: hintText,
              hintTextDirection: isRTL ? TextDirection.rtl : TextDirection.ltr,
              prefixIcon: Icon(prefixIcon, textDirection: TextDirection.rtl),
              border: InputBorder.none,
              contentPadding: EdgeInsets.symmetric(
                vertical: 16.h,
                horizontal: 16.w,
              ),
            ),
          ),
        ),
        if (errorText != null && errorText!.isNotEmpty)
          Padding(
            padding: EdgeInsets.only(top: 8.h),
            child: Neumorphic(
              style: NeumorphicStyle(
                depth: -3,
                intensity: 0.8,
                color: Colors.grey[200],
              ),
              padding: EdgeInsets.symmetric(
                horizontal: 12.w,
                vertical: 8.h,
              ),
              child: Text(
                errorText!,
                style: TextStyle(
                  color: Colors.red,
                  fontSize: 12.sp,
                ),
              ),
            ),
          ),
      ],
    );
  }
}