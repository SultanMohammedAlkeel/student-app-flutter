import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:student_app/app/routes/app_pages.dart';
import 'package:student_app/core/services/auth_service.dart';

import '../../../core/services/theme_service.dart';

class HomeController extends GetxController {
  final RxInt currentIndex = 0.obs;
  final RxBool isDarkMode = false.obs;
  final RxMap<String, dynamic> userData = RxMap();

  @override
  void onInit() {
    super.onInit();
    loadUserData();
    isDarkMode.value = ThemeService().theme == ThemeMode.dark;
  }

  Future<void> loadUserData() async {
    final user = await AuthService.getUser();
    if (user != null) {
      userData.assignAll(user.toJson());
    }
  }

  void changePage(int index) {
    currentIndex.value = index;
  }

  void toggleTheme() {
    isDarkMode.toggle();
    ThemeService().switchTheme();
  }

  void logout() {
    AuthService.clearAuthData();
    Get.offAllNamed(AppRoutes.login);
  }
}