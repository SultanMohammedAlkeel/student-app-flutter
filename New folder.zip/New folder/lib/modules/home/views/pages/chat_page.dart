import 'package:flutter_neumorphic_plus/flutter_neumorphic.dart';

class ChatPage extends StatelessWidget {
  const ChatPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Center(
      child: NeumorphicText(
        'Chat Page',
        style: NeumorphicStyle(
          color: NeumorphicTheme.isUsingDark(context)
              ? Colors.white
              : Colors.black87,
        ),
        textStyle:  NeumorphicTextStyle(
          fontSize: 24,
          fontWeight: FontWeight.bold,
        ),
      ),
    );
  }
}