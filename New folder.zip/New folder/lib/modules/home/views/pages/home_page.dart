import 'package:flutter/material.dart';
import 'package:flutter_neumorphic_plus/flutter_neumorphic.dart';
import 'package:get/get.dart';
import 'package:student_app/modules/home/controllers/home_controller.dart';

class HomePage extends StatelessWidget {
  const HomePage({super.key});

  @override
  Widget build(BuildContext context) {
    final controller = Get.find<HomeController>();
    
    return SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          NeumorphicText(
            'Welcome Back,',
            style: NeumorphicStyle(
              color: NeumorphicTheme.isUsingDark(context)
                  ? Colors.white
                  : Colors.black87,
            ),
            textStyle: NeumorphicTextStyle(
              fontSize: 24,
              fontWeight: FontWeight.bold,
            ),
          ),
          Obx(() => NeumorphicText(
            controller.userData['name'] ?? 'Student',
            style: NeumorphicStyle(
              color: NeumorphicTheme.isUsingDark(context)
                  ? Colors.white
                  : Colors.black87,
            ),
            textStyle:  NeumorphicTextStyle(
              fontSize: 32,
              fontWeight: FontWeight.bold,
            ),
          )),
          const SizedBox(height: 32),
          _buildDashboardItem(
            context,
            icon: Icons.school,
            title: 'My Courses',
            onTap: () {},
          ),
          _buildDashboardItem(
            context,
            icon: Icons.assignment,
            title: 'Assignments',
            onTap: () {},
          ),
          _buildDashboardItem(
            context,
            icon: Icons.calendar_today,
            title: 'Schedule',
            onTap: () {},
          ),
          _buildDashboardItem(
            context,
            icon: Icons.grade,
            title: 'Grades',
            onTap: () {},
          ),
        ],
      ),
    );
  }

  Widget _buildDashboardItem(
    BuildContext context, {
    required IconData icon,
    required String title,
    required VoidCallback onTap,
  }) {
    return GestureDetector(
      onTap: onTap,
      child: Neumorphic(
        margin: const EdgeInsets.only(bottom: 16),
        style: NeumorphicStyle(
          shape: NeumorphicShape.flat,
          boxShape: NeumorphicBoxShape.roundRect(BorderRadius.circular(12)),
          depth: 4,
        ),
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Row(
            children: [
              Neumorphic(
                style: NeumorphicStyle(
                  shape: NeumorphicShape.convex,
                  boxShape: NeumorphicBoxShape.circle(),
                  depth: 2,
                ),
                child: Padding(
                  padding: const EdgeInsets.all(12),
                  child: Icon(
                    icon,
                    size: 30,
                    color: NeumorphicTheme.isUsingDark(context)
                        ? Colors.white
                        : Colors.black87,
                  ),
                ),
              ),
              const SizedBox(width: 16),
              Expanded(
                child: NeumorphicText(
                  title,
                  style: NeumorphicStyle(
                    color: NeumorphicTheme.isUsingDark(context)
                        ? Colors.white
                        : Colors.black87,
                  ),
                  textStyle:  NeumorphicTextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
              Icon(
                Icons.arrow_forward_ios,
                color: NeumorphicTheme.isUsingDark(context)
                    ? Colors.white
                    : Colors.black87,
              ),
            ],
          ),
        ),
      ),
    );
  }
}