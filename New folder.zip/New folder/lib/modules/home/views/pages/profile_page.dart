import 'package:flutter/material.dart';
import 'package:flutter_neumorphic_plus/flutter_neumorphic.dart';
import 'package:get/get.dart';
import 'package:student_app/modules/home/controllers/home_controller.dart';

import '../../../auth/controllers/auth_controller.dart';

class ProfilePage extends StatelessWidget {
  final RxMap<String, dynamic> userData;

  const ProfilePage({super.key, required this.userData});

  @override
  Widget build(BuildContext context) {
    final controller = Get.find<HomeController>();
    
    return SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: Column(
        children: [
          Obx(() => _buildProfileAvatar(controller)),
          const SizedBox(height: 16),
          Obx(() => _buildUserInfo(controller)),
          const SizedBox(height: 32),
          _buildProfileActions(),
        ],
      ),
    );
  }

  Widget _buildProfileAvatar(HomeController controller) {
    return Neumorphic(
      style: NeumorphicStyle(
        shape: NeumorphicShape.convex,
        boxShape: NeumorphicBoxShape.circle(),
        depth: 8,
      ),
      child: Container(
        width: 120,
        height: 120,
        decoration: const BoxDecoration(
          shape: BoxShape.circle,
        ),
        child: Icon(
          Icons.person,
          size: 60,
          color: controller.isDarkMode.value ? Colors.white : Colors.black87,
        ),
      ),
    );
  }

  Widget _buildUserInfo(HomeController controller) {
    return Column(
      children: [
        NeumorphicText(
          controller.userData['name'] ?? 'Student',
          style: NeumorphicStyle(
            color: controller.isDarkMode.value ? Colors.white : Colors.black87,
          ),
          textStyle:  NeumorphicTextStyle(
            fontSize: 24,
            fontWeight: FontWeight.bold,
          ),
        ),
        const SizedBox(height: 8),
        NeumorphicText(
          controller.userData['email'] ?? 'student@university.edu',
          style: NeumorphicStyle(
            color: controller.isDarkMode.value ? Colors.white70 : Colors.black54,
          ),
          textStyle:  NeumorphicTextStyle(
            fontSize: 16,
          ),
        ),
      ],
    );
  }

  Widget _buildProfileActions() {
    return Column(
      children: [
        _buildProfileItem(Icons.school, 'Student ID', userData['user_id']?.toString() ?? 'N/A'),
        _buildProfileItem(Icons.phone, 'Phone', userData['phone_number'] ?? 'Not provided'),
        _buildProfileItem(Icons.calendar_today, 'Member since', 
            userData['created_at']?.toString().split('T')[0] ?? 'N/A'),
        const SizedBox(height: 32),
        NeumorphicButton(
          onPressed: () {
            Get.find<AuthController>().logout();
          },
          style: NeumorphicStyle(
            shape: NeumorphicShape.flat,
            boxShape: NeumorphicBoxShape.roundRect(BorderRadius.circular(12)),
            depth: 4,
            color: Colors.red.shade400,
          ),
          child: const Padding(
            padding: EdgeInsets.symmetric(horizontal: 24, vertical: 12),
            child: Text(
              'Logout',
              style: TextStyle(color: Colors.white),
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildProfileItem(IconData icon, String title, String value) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 16),
      child: Neumorphic(
        style: NeumorphicStyle(
          shape: NeumorphicShape.flat,
          boxShape: NeumorphicBoxShape.roundRect(BorderRadius.circular(12)),
          depth: 2,
        ),
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Row(
            children: [
              Icon(icon),
              const SizedBox(width: 16),
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    title,
                    style: const TextStyle(fontSize: 14, color: Colors.grey),
                  ),
                  Text(
                    value,
                    style: const TextStyle(
                      fontSize: 16,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}