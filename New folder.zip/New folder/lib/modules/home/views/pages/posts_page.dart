import 'package:flutter_neumorphic_plus/flutter_neumorphic.dart';

class PostsPage extends StatelessWidget {
  const PostsPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Center(
      child: NeumorphicText(
        'Posts Page',
        style: NeumorphicStyle(
          color: NeumorphicTheme.isUsingDark(context)
              ? Colors.white
              : Colors.black87,
        ),
        textStyle:  NeumorphicTextStyle(
          fontSize: 24,
          fontWeight: FontWeight.bold,
        ),
      ),
    );
  }
}