import 'package:flutter_neumorphic_plus/flutter_neumorphic.dart';
import 'package:get/get.dart';
import 'package:student_app/modules/home/controllers/home_controller.dart';

class HomeAppBar extends StatelessWidget implements PreferredSizeWidget {
  const HomeAppBar({super.key});

  @override
  Widget build(BuildContext context) {
    final controller = Get.find<HomeController>();
    
    return NeumorphicAppBar(
      title: NeumorphicText(
        'Student App',
        style: NeumorphicStyle(
          color: NeumorphicTheme.isUsingDark(context) 
              ? Colors.white 
              : Colors.black87,
        ),
        textStyle: NeumorphicTextStyle(
          fontSize: 20,
          fontWeight: FontWeight.bold,
        ),
      ),
      leading: Obx(() => NeumorphicButton(
        style: NeumorphicStyle(
          shape: NeumorphicShape.flat,
          boxShape: NeumorphicBoxShape.circle(),
          depth: 2,
          color: Colors.transparent,
          shadowLightColor: controller.isDarkMode.value 
              ? Colors.grey[800]!
              : Colors.white,
          shadowDarkColor: controller.isDarkMode.value
              ? Colors.black
              : Colors.grey.shade400,
        ),
        padding: const EdgeInsets.all(12),
        onPressed: () {
          Scaffold.of(context).openDrawer();
        },
        child: Icon(
          Icons.menu,
          color: controller.isDarkMode.value 
              ? Colors.white 
              : Colors.black87,
        ),
      )),
      actions: [
        Padding(
          padding: const EdgeInsets.only(right: 8.0),
          child: Neumorphic(
            style: NeumorphicStyle(
              shape: NeumorphicShape.convex,
              boxShape: NeumorphicBoxShape.circle(),
              depth: 4,
              intensity: 0.7,
              color: NeumorphicTheme.baseColor(context),
            ),
            child: IconButton(
              iconSize: 24,
              padding: EdgeInsets.zero,
              icon: Obx(() => Icon(
                controller.isDarkMode.value 
                    ? Icons.light_mode 
                    : Icons.dark_mode,
                color: NeumorphicTheme.isUsingDark(context)
                    ? Colors.white
                    : Colors.black87,
              )),
              onPressed: controller.toggleTheme,
            ),
          ),
        ),
      ],
    );
  }

  @override
  Size get preferredSize => const Size.fromHeight(kToolbarHeight);
}