import 'package:flutter_neumorphic_plus/flutter_neumorphic.dart';
import 'package:get/get.dart';
import 'package:student_app/modules/home/controllers/home_controller.dart';
import 'package:student_app/modules/home/views/widgets/app_bar.dart';
import 'package:student_app/modules/home/views/widgets/bottom_nav_bar.dart';
import 'package:student_app/modules/home/views/widgets/drawer_menu.dart';
import 'package:student_app/modules/home/views/pages/chat_page.dart';
import 'package:student_app/modules/home/views/pages/home_page.dart';
import 'package:student_app/modules/home/views/pages/posts_page.dart';
import 'package:student_app/modules/home/views/pages/profile_page.dart';

import '../../../core/constants/app_constants.dart';

class HomeView extends GetView<HomeController> {
  const HomeView({super.key});

  @override
  Widget build(BuildContext context) {
    final pages = [
      const HomePage(),
      const ChatPage(),
      const PostsPage(),
      ProfilePage(userData: controller.userData),
    ];

    return Obx(() {
      final isDarkMode = controller.isDarkMode.value;

      return NeumorphicTheme(
        themeMode: isDarkMode ? ThemeMode.dark : ThemeMode.light,
        theme: NeumorphicThemeData(
          baseColor: AppConstants.lightBackgroundColor,
          lightSource: LightSource.topLeft,
          depth: AppConstants.lightDepth,
          intensity: AppConstants.lightIntensity,
        ),
        darkTheme: NeumorphicThemeData(
          baseColor: AppConstants.darkBackgroundColor,
          lightSource: LightSource.topLeft,
          depth: AppConstants.darkDepth,
          intensity: AppConstants.darkIntensity,
        ),
        child: Scaffold(
          backgroundColor: AppConstants.getBackgroundColor(isDarkMode),
          appBar: const HomeAppBar(),
          drawer: const HomeDrawerMenu(),
          body: AnimatedSwitcher(
            duration: const Duration(milliseconds: 500),
            child: IndexedStack(
              index: controller.currentIndex.value,
              children: pages,
            ),
          ),
          bottomNavigationBar: const HomeBottomNavBar(),
        ),
      );
    });
  }
}
